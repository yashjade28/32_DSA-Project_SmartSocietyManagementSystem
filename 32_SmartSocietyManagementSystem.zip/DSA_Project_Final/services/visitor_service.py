"""
Visitor Service Layer
Business logic for visitor management using Queue (FIFO)
"""

import json
import os
from dsa_structures.queue import Queue


class VisitorService:
    """
    Service layer for visitor operations
    Uses Queue for FIFO processing
    """
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.visitors_file = os.path.join(data_dir, 'visitors.json')
        
        # Initialize Queue
        self.visitor_queue = Queue()
        
        # Load existing data
        self.load_data()
    
    def load_data(self):
        """Load visitors from JSON file"""
        if os.path.exists(self.visitors_file):
            with open(self.visitors_file, 'r') as f:
                visitors = json.load(f)
                for visitor in visitors:
                    self.visitor_queue.enqueue(visitor)
    
    def save_visitors(self):
        """Save visitors to JSON file"""
        visitors = self.visitor_queue.get_all()
        with open(self.visitors_file, 'w') as f:
            json.dump(visitors, f, indent=2)
    
    def enqueue_visitor(self, visitor_data):
        """Add visitor to queue (enqueue)"""
        self.visitor_queue.enqueue(visitor_data)
        self.save_visitors()
        return True
    
    def dequeue_visitor(self):
        """Process next visitor (dequeue)"""
        visitor = self.visitor_queue.dequeue()
        if visitor:
            self.save_visitors()
        return visitor
    
    def get_all(self):
        """Get all visitors in queue"""
        return self.visitor_queue.get_all()
    
    def get_count(self):
        """Get visitor queue size"""
        return self.visitor_queue.size()
    
    def peek_next(self):
        """View next visitor without removing"""
        return self.visitor_queue.peek()
    
    def initialize_sample_data(self):
        """Initialize with sample data if file doesn't exist"""
        if not os.path.exists(self.visitors_file):
            sample_visitors = [
                {'name': 'Suresh Menon', 'flat': 'A-101', 'purpose': 'Personal Visit', 'time': '09:30 AM'},
                {'name': 'Kavita Singh', 'flat': 'B-201', 'purpose': 'Delivery', 'time': '10:15 AM'}
            ]
            for visitor in sample_visitors:
                self.visitor_queue.enqueue(visitor)
            self.save_visitors()
