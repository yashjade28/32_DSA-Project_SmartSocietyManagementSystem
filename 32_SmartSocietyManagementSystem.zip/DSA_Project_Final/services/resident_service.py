"""
Resident Service Layer - Enhanced with Search & Sort Algorithms
Binary Search + Quick Sort implementation
"""

import json
import os
from dsa_structures.linked_list import LinkedList
from dsa_structures.stack import Stack


class ResidentService:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.residents_file = os.path.join(data_dir, 'residents.json')
        self.bills_file = os.path.join(data_dir, 'bills.json')
        
        self.resident_list = LinkedList()
        self.billing_stack = Stack()
        
        self.load_data()
    
    def load_data(self):
        if os.path.exists(self.residents_file):
            with open(self.residents_file, 'r') as f:
                residents = json.load(f)
                for resident in residents:
                    self.resident_list.add(resident)
        
        if os.path.exists(self.bills_file):
            with open(self.bills_file, 'r') as f:
                bills = json.load(f)
                for bill in bills:
                    self.billing_stack.push(bill)
    
    def save_residents(self):
        residents = self.resident_list.get_all()
        with open(self.residents_file, 'w') as f:
            json.dump(residents, f, indent=2)
    
    def save_bills(self):
        bills = self.billing_stack.get_all()
        with open(self.bills_file, 'w') as f:
            json.dump(bills[::-1], f, indent=2)
    
    def add_resident(self, resident_data):
        self.resident_list.add(resident_data)
        self.save_residents()
        return True
    
    def delete_resident(self, flat_number):
        success = self.resident_list.remove(flat_number)
        if success:
            self.save_residents()
        return success
    
    def get_all(self):
        return self.resident_list.get_all()
    
    def get_count(self):
        return self.resident_list.get_size()
    
    # ==================== BINARY SEARCH ====================
    def search_by_flat(self, flat_number):
        """
        Binary Search for resident by flat number
        Time Complexity: O(log n) after sorting
        Real-world: Quickly find resident information
        """
        residents = self.get_all()
        # Sort by flat number first
        residents.sort(key=lambda x: x['flat'])
        
        left, right = 0, len(residents) - 1
        
        while left <= right:
            mid = (left + right) // 2
            if residents[mid]['flat'] == flat_number:
                return residents[mid]
            elif residents[mid]['flat'] < flat_number:
                left = mid + 1
            else:
                right = mid - 1
        
        return None
    
    # ==================== QUICK SORT ====================
    def sort_residents(self, sort_by='name'):
        """
        Quick Sort implementation for sorting residents
        Time Complexity: O(n log n) average case
        Real-world: Sort residents by name, flat, or pending bills
        """
        residents = self.get_all()
        
        if sort_by == 'name':
            return self._quick_sort(residents, lambda x: x['name'])
        elif sort_by == 'flat':
            return self._quick_sort(residents, lambda x: x['flat'])
        elif sort_by == 'bills':
            # Calculate pending bills for each resident
            bills = self.billing_stack.get_all()
            bill_map = {}
            for bill in bills:
                bill_map[bill['flat']] = bill_map.get(bill['flat'], 0) + bill['amount']
            
            # Add bill amount to each resident
            for r in residents:
                r['pending_bills'] = bill_map.get(r['flat'], 0)
            
            return self._quick_sort(residents, lambda x: x.get('pending_bills', 0), reverse=True)
        
        return residents
    
    def _quick_sort(self, arr, key_func, reverse=False):
        """Quick Sort helper function"""
        if len(arr) <= 1:
            return arr
        
        pivot = arr[len(arr) // 2]
        pivot_key = key_func(pivot)
        
        if reverse:
            left = [x for x in arr if key_func(x) > pivot_key]
            middle = [x for x in arr if key_func(x) == pivot_key]
            right = [x for x in arr if key_func(x) < pivot_key]
        else:
            left = [x for x in arr if key_func(x) < pivot_key]
            middle = [x for x in arr if key_func(x) == pivot_key]
            right = [x for x in arr if key_func(x) > pivot_key]
        
        return self._quick_sort(left, key_func, reverse) + middle + self._quick_sort(right, key_func, reverse)
    
    # Billing operations
    def add_bill(self, bill_data):
        self.billing_stack.push(bill_data)
        self.save_bills()
        return True
    
    def undo_bill(self):
        bill = self.billing_stack.pop()
        if bill:
            self.save_bills()
        return bill
    
    def get_all_bills(self):
        return self.billing_stack.get_all()
    
    def get_total_billing(self):
        bills = self.billing_stack.get_all()
        return sum(bill['amount'] for bill in bills)
    
    def initialize_sample_data(self):
        if not os.path.exists(self.residents_file):
            sample_residents = [
                {'name': 'Rajesh Kumar', 'flat': 'A-101', 'phone': '+91 98765 43210', 'email': 'rajesh@example.com'},
                {'name': 'Priya Sharma', 'flat': 'A-102', 'phone': '+91 98765 43211', 'email': 'priya@example.com'},
                {'name': 'Amit Patel', 'flat': 'B-201', 'phone': '+91 98765 43212', 'email': 'amit@example.com'}
            ]
            for resident in sample_residents:
                self.resident_list.add(resident)
            self.save_residents()
        
        if not os.path.exists(self.bills_file):
            sample_bills = [
                {'flat': 'A-101', 'amount': 5000, 'desc': 'Monthly Maintenance', 'date': '2024-01-15'},
                {'flat': 'A-102', 'amount': 5000, 'desc': 'Monthly Maintenance', 'date': '2024-01-15'},
                {'flat': 'B-201', 'amount': 6000, 'desc': 'Maintenance + Parking', 'date': '2024-01-15'}
            ]
            for bill in sample_bills:
                self.billing_stack.push(bill)
            self.save_bills()
