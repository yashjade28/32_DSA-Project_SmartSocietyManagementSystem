"""
Tree Implementation - Building Hierarchy
Real-world use: Tower → Floor → Flat structure
Represents society layout in hierarchical format
"""

class TreeNode:
    """
    Node representing a level in hierarchy
    Can be Tower, Floor, or Flat
    """
    def __init__(self, name, node_type, data=None):
        self.name = name  # e.g., "Tower A", "Floor 1", "Flat 101"
        self.node_type = node_type  # "tower", "floor", "flat"
        self.data = data  # Additional data (residents, etc.)
        self.children = []  # Child nodes
    
    def add_child(self, child_node):
        """Add child (e.g., add floor to tower)"""
        self.children.append(child_node)
    
    def get_children(self):
        """Get all children"""
        return self.children


class SocietyTree:
    """
    Tree structure for society layout
    Root → Towers → Floors → Flats
    Real-world mapping: Physical building structure
    """
    def __init__(self, society_name):
        self.root = TreeNode(society_name, "society")
    
    def add_tower(self, tower_name):
        """Add tower to society"""
        tower = TreeNode(tower_name, "tower")
        self.root.add_child(tower)
        return tower
    
    def add_floor(self, tower, floor_number):
        """Add floor to tower"""
        floor = TreeNode(f"Floor {floor_number}", "floor")
        tower.add_child(floor)
        return floor
    
    def add_flat(self, floor, flat_number, resident_data=None):
        """Add flat to floor"""
        flat = TreeNode(f"Flat {flat_number}", "flat", resident_data)
        floor.add_child(flat)
        return flat
    
    def get_all_towers(self):
        """Get all towers in society"""
        return self.root.get_children()
    
    def get_tower_structure(self, tower):
        """Get complete structure of a tower"""
        structure = {
            'name': tower.name,
            'floors': []
        }
        for floor in tower.get_children():
            floor_data = {
                'name': floor.name,
                'flats': [flat.name for flat in floor.get_children()]
            }
            structure['floors'].append(floor_data)
        return structure
    
    def search_flat(self, flat_number):
        """
        Search for flat across all towers
        Time Complexity: O(n) where n = total flats
        Real-world: Find resident location quickly
        """
        for tower in self.root.get_children():
            for floor in tower.get_children():
                for flat in floor.get_children():
                    if flat_number in flat.name:
                        return {
                            'tower': tower.name,
                            'floor': floor.name,
                            'flat': flat.name,
                            'data': flat.data
                        }
        return None
    
    def get_total_flats(self):
        """Count total flats in society"""
        count = 0
        for tower in self.root.get_children():
            for floor in tower.get_children():
                count += len(floor.get_children())
        return count
