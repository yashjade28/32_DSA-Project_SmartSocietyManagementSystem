"""
Linked List Implementation
Real-world use: Dynamic resident management with frequent insertions/deletions
Time Complexity: Insert O(n), Delete O(n), Search O(n)
Space Complexity: O(n)
"""

class Node:
    """
    Node represents a single resident in the society
    Contains resident data and pointer to next resident
    """
    def __init__(self, data):
        self.data = data  # Resident information (name, flat, phone, email)
        self.next = None  # Pointer to next node


class LinkedList:
    """
    Linked List for managing residents dynamically
    Why use this? Allows efficient insertion/deletion without array reallocation
    Unlike arrays, no need to shift elements when adding/removing residents
    """
    def __init__(self):
        self.head = None  # First resident in list
        self.size = 0     # Total number of residents
    
    def add(self, data):
        """
        Add resident at the end of list
        Time Complexity: O(n) - traverse to end
        Real-world: New resident moves into society
        """
        new_node = Node(data)
        
        if not self.head:
            # First resident in the society
            self.head = new_node
        else:
            # Traverse to last resident and add new one
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        
        self.size += 1
        return True
    
    def remove(self, flat_number):
        """
        Remove resident by flat number
        Time Complexity: O(n) - may need to traverse entire list
        Real-world: Resident moves out of society
        """
        if not self.head:
            return False
        
        # If head node needs to be removed
        if self.head.data['flat'] == flat_number:
            self.head = self.head.next
            self.size -= 1
            return True
        
        # Search for the node to be deleted
        current = self.head
        while current.next:
            if current.next.data['flat'] == flat_number:
                current.next = current.next.next
                self.size -= 1
                return True
            current = current.next
        
        return False
    
    def search(self, flat_number):
        """
        Find resident by flat number
        Time Complexity: O(n)
        Real-world: Look up resident information
        """
        current = self.head
        while current:
            if current.data['flat'] == flat_number:
                return current.data
            current = current.next
        return None
    
    def get_all(self):
        """
        Get all residents as a list
        Time Complexity: O(n)
        Real-world: Display all society members
        """
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result
    
    def get_size(self):
        """Return total number of residents"""
        return self.size
    
    def is_empty(self):
        """Check if society has any residents"""
        return self.head is None
