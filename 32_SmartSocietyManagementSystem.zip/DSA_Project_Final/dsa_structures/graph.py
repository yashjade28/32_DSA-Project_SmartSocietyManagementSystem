"""
Graph Implementation (Adjacency List)
Real-world use: Represent connected facilities in society
Time Complexity: Add Vertex O(1), Add Edge O(1), Get Connections O(1)
Space Complexity: O(V + E) where V = vertices, E = edges
"""

class Graph:
    """
    Graph for modeling facility connections
    Why Graph? Some facilities are connected (gym near pool)
    Helps in planning maintenance, access routes, etc.
    Real-world: Pool and gym share same building, parking near garden
    """
    def __init__(self):
        # Adjacency list representation
        # Key: facility name, Value: list of connected facilities
        self.adjacency_list = {}
    
    def add_vertex(self, vertex):
        """
        Add new facility
        Time Complexity: O(1)
        Real-world: New amenity added to society
        """
        if vertex not in self.adjacency_list:
            self.adjacency_list[vertex] = []
        return True
    
    def add_edge(self, vertex1, vertex2):
        """
        Add connection between two facilities (undirected)
        Time Complexity: O(1)
        Real-world: Two facilities are physically connected
        Example: Gym and Swimming Pool in same building
        """
        # Add both vertices if they don't exist
        self.add_vertex(vertex1)
        self.add_vertex(vertex2)
        
        # Add edge in both directions (undirected graph)
        if vertex2 not in self.adjacency_list[vertex1]:
            self.adjacency_list[vertex1].append(vertex2)
        if vertex1 not in self.adjacency_list[vertex2]:
            self.adjacency_list[vertex2].append(vertex1)
        
        return True
    
    def remove_edge(self, vertex1, vertex2):
        """
        Remove connection between facilities
        Real-world: Facilities no longer directly accessible
        """
        if vertex1 in self.adjacency_list and vertex2 in self.adjacency_list[vertex1]:
            self.adjacency_list[vertex1].remove(vertex2)
        if vertex2 in self.adjacency_list and vertex1 in self.adjacency_list[vertex2]:
            self.adjacency_list[vertex2].remove(vertex1)
        return True
    
    def remove_vertex(self, vertex):
        """
        Remove facility and all its connections
        Real-world: Facility permanently closed
        """
        if vertex not in self.adjacency_list:
            return False
        
        # Remove all edges to this vertex
        for adjacent_vertex in self.adjacency_list[vertex]:
            self.adjacency_list[adjacent_vertex].remove(vertex)
        
        # Remove vertex itself
        del self.adjacency_list[vertex]
        return True
    
    def get_connections(self, vertex):
        """
        Get all facilities connected to given facility
        Time Complexity: O(1)
        Real-world: Find all nearby amenities
        """
        return self.adjacency_list.get(vertex, [])
    
    def get_vertices(self):
        """
        Get all facilities
        Real-world: List all society amenities
        """
        return list(self.adjacency_list.keys())
    
    def has_edge(self, vertex1, vertex2):
        """
        Check if two facilities are connected
        Real-world: Is gym directly accessible from pool?
        """
        return vertex1 in self.adjacency_list and vertex2 in self.adjacency_list[vertex1]
    
    def get_all_edges(self):
        """
        Get all facility connections
        Real-world: Display all connected amenities
        """
        edges = []
        for vertex in self.adjacency_list:
            for neighbor in self.adjacency_list[vertex]:
                # Avoid duplicates (since undirected)
                edge = tuple(sorted([vertex, neighbor]))
                if edge not in edges:
                    edges.append(edge)
        return edges
    
    def display(self):
        """
        Pretty print graph structure
        For debugging and visualization
        """
        for vertex in self.adjacency_list:
            connections = ', '.join(self.adjacency_list[vertex])
            print(f"{vertex} -> {connections}")
