"""
Min Heap Implementation (Priority Queue)
Real-world use: Complaint management based on urgency
Time Complexity: Insert O(log n), Extract Min O(log n)
Space Complexity: O(n)
Priority: 1 (High) > 2 (Medium) > 3 (Low)
"""

class MinHeap:
    """
    Min Heap for priority-based complaint resolution
    Why Min Heap? Lower priority number = higher urgency
    Automatically keeps most urgent complaint at top
    Real-world: Emergency leaks resolved before minor issues
    """
    def __init__(self):
        self.heap = []  # Array representation of heap
    
    def get_parent_index(self, index):
        """Get index of parent node"""
        return (index - 1) // 2
    
    def get_left_child_index(self, index):
        """Get index of left child"""
        return 2 * index + 1
    
    def get_right_child_index(self, index):
        """Get index of right child"""
        return 2 * index + 2
    
    def has_parent(self, index):
        """Check if node has parent"""
        return self.get_parent_index(index) >= 0
    
    def has_left_child(self, index):
        """Check if node has left child"""
        return self.get_left_child_index(index) < len(self.heap)
    
    def has_right_child(self, index):
        """Check if node has right child"""
        return self.get_right_child_index(index) < len(self.heap)
    
    def swap(self, index1, index2):
        """Swap two elements in heap"""
        self.heap[index1], self.heap[index2] = self.heap[index2], self.heap[index1]
    
    def insert(self, item):
        """
        Insert complaint into heap
        Time Complexity: O(log n)
        Real-world: New complaint submitted
        Process: Add to end, then bubble up to maintain heap property
        """
        self.heap.append(item)
        self.heapify_up(len(self.heap) - 1)
    
    def heapify_up(self, index):
        """
        Move element up to maintain min heap property
        Compare with parent, swap if current is smaller (higher priority)
        """
        while self.has_parent(index):
            parent_index = self.get_parent_index(index)
            if self.heap[index]['priority'] < self.heap[parent_index]['priority']:
                self.swap(index, parent_index)
                index = parent_index
            else:
                break
    
    def extract_min(self):
        """
        Remove and return highest priority complaint
        Time Complexity: O(log n)
        Real-world: Resolve most urgent complaint
        Process: Remove root, replace with last element, heapify down
        """
        if len(self.heap) == 0:
            return None
        
        if len(self.heap) == 1:
            return self.heap.pop()
        
        # Store minimum (root)
        min_item = self.heap[0]
        
        # Replace root with last element
        self.heap[0] = self.heap.pop()
        
        # Restore heap property
        self.heapify_down(0)
        
        return min_item
    
    def heapify_down(self, index):
        """
        Move element down to maintain min heap property
        Compare with children, swap with smaller child if needed
        """
        while self.has_left_child(index):
            smaller_child_index = self.get_left_child_index(index)
            
            # Check if right child is smaller
            if self.has_right_child(index):
                right_child_index = self.get_right_child_index(index)
                if self.heap[right_child_index]['priority'] < self.heap[smaller_child_index]['priority']:
                    smaller_child_index = right_child_index
            
            # If current is smaller than smallest child, done
            if self.heap[index]['priority'] < self.heap[smaller_child_index]['priority']:
                break
            
            # Swap with smaller child
            self.swap(index, smaller_child_index)
            index = smaller_child_index
    
    def peek(self):
        """View highest priority complaint without removing"""
        if len(self.heap) == 0:
            return None
        return self.heap[0]
    
    def get_all(self):
        """
        Get all complaints sorted by priority
        Real-world: Display complaint list
        """
        return sorted(self.heap, key=lambda x: x['priority'])
    
    def size(self):
        """Return total number of complaints"""
        return len(self.heap)
    
    def is_empty(self):
        """Check if no complaints exist"""
        return len(self.heap) == 0
